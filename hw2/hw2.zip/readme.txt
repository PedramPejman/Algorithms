Pedram Pejman
compile using javac Hw2.java
