compile using make.
Pedram Pejman 
